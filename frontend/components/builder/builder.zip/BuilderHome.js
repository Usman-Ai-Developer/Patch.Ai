export default function BuilderHome({ onSelectBackend, onSelectFrontend }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8">
      <h2 className="text-2xl font-bold glow-text mb-2">What would you like to build today?</h2>
      <p className="text-subtext mb-8 text-center max-w-xl">
        Choose your development area to get started.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl w-full">
        {/* Backend Card */}
        <div
          onClick={onSelectBackend}
          className="bg-panel border border-line rounded-xl p-6 hover:border-brand-100/50 transition-all cursor-pointer group"
        >
          <div className="text-4xl mb-3">⚙️</div>
          <h3 className="text-lg font-semibold text-text group-hover:text-brand-100 transition-colors">Backend</h3>
          <p className="text-sm text-subtext mt-1">
            Build APIs, database models, business logic, workflows and automations.
          </p>
        </div>

        {/* Frontend Card (coming soon) */}
        <div
          onClick={onSelectFrontend}
          className="bg-panel border border-line rounded-xl p-6 opacity-60 cursor-not-allowed"
        >
          <div className="text-4xl mb-3">🎨</div>
          <h3 className="text-lg font-semibold text-text">Frontend</h3>
          <p className="text-sm text-subtext mt-1">
            Design beautiful interfaces, pages, components and layouts.
            <span className="block text-xs text-subtext/50 mt-1">Coming soon</span>
          </p>
        </div>
      </div>
    </div>
  );
}