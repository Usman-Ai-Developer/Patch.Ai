"use client";

import ProjectTree from "./ProjectTree";

export default function AppExplorer({
  blueprint,
  apps,
  expandedApps,
  onToggleExpansion,
  onItemClick,
  onAppClick,
  onDeleteApp,
  onGenerate,
  generating,
  onRefreshApps,
  onClose,
  onEnableAuth,
  enablingAuth,
  onNewApp,
  onCreateSuperuser,
}) {
  return (
    <div className="h-full flex flex-col bg-ink">
      {/* ─── Header ──────────────────────────────────────────────── */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-line shrink-0">
        <span className="text-sm text-subtext">
          Apps – {blueprint.framework} (Project: {blueprint.data?.project_name || "Unnamed"})
        </span>
        <div className="flex gap-2">
          <button
            onClick={onGenerate}
            disabled={generating}
            className="text-xs px-3 py-1 bg-mint/20 text-mint rounded hover:bg-mint/30 transition-colors disabled:opacity-40"
          >
            {generating ? "Generating…" : "🚀 Generate"}
          </button>
          <button
            onClick={onRefreshApps}
            className="text-xs px-3 py-1 bg-brand-100/20 text-brand-100 rounded hover:bg-brand-100/30 transition-colors"
          >
            ⟳ Refresh
          </button>
          <button onClick={onClose} className="text-subtext hover:text-red-400 text-sm">
            ✕
          </button>
        </div>
      </div>

      {/* ─── Main content ─────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-text">Project Structure</h3>
          <div className="flex gap-2">
            <button
              onClick={onEnableAuth}
              disabled={enablingAuth}
              className="text-xs px-3 py-1 bg-yellow-500/20 text-yellow-500 rounded hover:bg-yellow-500/30 transition-colors disabled:opacity-40"
            >
              {enablingAuth ? "Enabling…" : "🔐 Enable Auth"}
            </button>
            <button
              onClick={onCreateSuperuser}
              className="text-xs px-3 py-1 bg-mint/20 text-mint rounded hover:bg-mint/30 transition-colors"
            >
              👤 Create Superuser
            </button>
            <button
              onClick={onNewApp}
              className="text-xs px-3 py-1 bg-brand-100/20 text-brand-100 rounded hover:bg-brand-100/30 transition-colors"
            >
              + New App
            </button>
          </div>
        </div>

        <ProjectTree
          apps={apps}
          expandedApps={expandedApps}
          onToggleExpansion={onToggleExpansion}
          onItemClick={onItemClick}
          onAppClick={onAppClick}
          onDeleteApp={onDeleteApp}
        />
      </div>
    </div>
  );
}