"use client";

import { useState, useEffect } from "react";
import toast from "react-hot-toast";
import {
  getBlueprint,
  updateBlueprint,
  generateProject,
  getAppsStructure,
  createApp,
  startProject,
  deleteApp,
  createSuperuser,
  enableAuth,
} from "../lib/api";

import BuilderHome from "./builder/BuilderHome";
import AppList from "./builder/AppList";
import AppDetails from "./builder/AppDetails";
import ModelDesigner from "./builder/ModelDesigner";
import Breadcrumb from "./builder/Breadcrumb";
import StartProjectModal from "./builder/StartProjectModal";
import NewAppModal from "./builder/NewAppModal";
import SuperuserModal from "./builder/SuperuserModal";

function isNotFoundError(err) {
  const status = err?.status ?? err?.statusCode ?? err?.response?.status ?? err?.cause?.status;
  if (status === 404) return true;
  return typeof err?.message === "string" && /not\s*found/i.test(err.message);
}

function isValidAppName(name) {
  return /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name);
}

export default function BuilderPanel({
  projectId,
  onClose,
  onProjectStarted,
  onSelectFile,
  onRefreshWorkspace,
}) {
  const [blueprint, setBlueprint] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [apps, setApps] = useState([]);
  const [expandedApps, setExpandedApps] = useState({});
  const [selectedApp, setSelectedApp] = useState(null);
  const [designerModels, setDesignerModels] = useState([]);

  // ─── Navigation state ──────────────────────────────────────────────
  const [view, setView] = useState('home'); // 'home' | 'apps' | 'app-details' | 'designer'
  const [currentApp, setCurrentApp] = useState(null);
  const [currentFeature, setCurrentFeature] = useState(null);

  // ─── Modals ──────────────────────────────────────────────────────
  const [showStartModal, setShowStartModal] = useState(false);
  const [showNewAppModal, setShowNewAppModal] = useState(false);
  const [showSuperuserModal, setShowSuperuserModal] = useState(false);

  const [newAppName, setNewAppName] = useState("");
  const [creatingApp, setCreatingApp] = useState(false);
  const [startFramework, setStartFramework] = useState("drf");
  const [startProjectName, setStartProjectName] = useState("");
  const [startAppName, setStartAppName] = useState("");
  const [startingProject, setStartingProject] = useState(false);
  const [superuserData, setSuperuserData] = useState({
    username: "",
    email: "",
    password: "",
    password2: "",
  });
  const [creatingSuperuser, setCreatingSuperuser] = useState(false);
  const [enablingAuth, setEnablingAuth] = useState(false);

  // ─── Fetch data ──────────────────────────────────────────────────
  useEffect(() => {
    const fetchData = async () => {
      try {
        const blueprintData = await getBlueprint(projectId);
        setBlueprint(blueprintData);
        if (blueprintData) {
          const appsData = await getAppsStructure(projectId);
          setApps(appsData);
        }
      } catch (err) {
        if (isNotFoundError(err)) {
          setBlueprint(null);
          setApps([]);
        } else {
          console.error(err);
          toast.error("Failed to load builder data");
        }
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [projectId]);

  useEffect(() => {
    if (blueprint && currentApp) {
      const allModels = blueprint.data.models || [];
      const filtered = allModels.filter((m) => m.app_name === currentApp);
      setDesignerModels(filtered);
    } else {
      setDesignerModels([]);
    }
  }, [blueprint, currentApp]);

  // ─── Actions ──────────────────────────────────────────────────────
  const saveBlueprint = async () => {
    setSaving(true);
    try {
      const updated = await updateBlueprint(projectId, blueprint.data);
      setBlueprint(updated);
      toast.success("Blueprint saved");
    } catch (err) {
      toast.error("Failed to save blueprint");
    } finally {
      setSaving(false);
    }
  };

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      await generateProject(projectId);
      toast.success("Code generated successfully!");
      const appsData = await getAppsStructure(projectId);
      setApps(appsData);
      if (onProjectStarted) onProjectStarted();
      if (onRefreshWorkspace) onRefreshWorkspace();
    } catch (err) {
      toast.error(err.message || "Failed to generate code");
    } finally {
      setGenerating(false);
    }
  };

  const handleRefreshApps = async () => {
    try {
      const appsData = await getAppsStructure(projectId);
      setApps(appsData);
      toast.success("App list refreshed");
      if (onRefreshWorkspace) onRefreshWorkspace();
    } catch (err) {
      toast.error("Failed to refresh apps");
    }
  };

  // ─── Navigation handlers ──────────────────────────────────────────
  const goToHome = () => {
    setView('home');
    setCurrentApp(null);
    setCurrentFeature(null);
  };

  const selectBackend = () => {
    setView('apps');
  };

  const selectFrontend = () => {
    toast("Frontend development coming soon!", { icon: '🚧' });
  };

  const selectApp = (appName) => {
    setCurrentApp(appName);
    setView('app-details');
  };

  const selectFeature = (feature) => {
    if (feature === 'models') {
      setView('designer');
      setCurrentFeature('models');
    } else {
      toast(`"${feature}" feature coming soon!`, { icon: '🚧' });
    }
  };

  const navigateBreadcrumb = (index) => {
    if (index === 0) goToHome();
    else if (index === 1 && view === 'app-details') setView('apps');
    else if (index === 1 && view === 'designer') setView('apps');
    else if (index === 2 && view === 'designer') {
      setView('app-details');
    }
  };

  // ─── Model CRUD ──────────────────────────────────────────────────
  const addModel = () => {
    if (!currentApp) return;
    const newModel = {
      name: "NewModel",
      app_name: currentApp,
      fields: [],
      relationships: [],
      permissions: [],
      filter_fields: [],
      search_fields: [],
      ordering_fields: [],
      admin: { list_display: [], search_fields: [] },
    };
    const updatedModels = [...blueprint.data.models, newModel];
    setBlueprint({
      ...blueprint,
      data: { ...blueprint.data, models: updatedModels },
    });
  };

  const updateModel = (index, updatedModel) => {
    const filtered = blueprint.data.models.filter((m) => m.app_name === currentApp);
    if (index >= filtered.length) return;
    const modelToUpdate = filtered[index];
    const globalIndex = blueprint.data.models.indexOf(modelToUpdate);
    if (globalIndex === -1) return;
    const newModels = [...blueprint.data.models];
    newModels[globalIndex] = updatedModel;
    setBlueprint({
      ...blueprint,
      data: { ...blueprint.data, models: newModels },
    });
  };

  const deleteModel = (filteredIndex) => {
    const filtered = blueprint.data.models.filter((m) => m.app_name === currentApp);
    if (filteredIndex >= filtered.length) return;
    const modelToDelete = filtered[filteredIndex];
    const globalIndex = blueprint.data.models.indexOf(modelToDelete);
    if (globalIndex === -1) return;
    const newModels = blueprint.data.models.filter((_, i) => i !== globalIndex);
    setBlueprint({
      ...blueprint,
      data: { ...blueprint.data, models: newModels },
    });
  };

  const addField = (filteredIndex) => {
    const filtered = blueprint.data.models.filter((m) => m.app_name === currentApp);
    if (filteredIndex >= filtered.length) return;
    const model = filtered[filteredIndex];
    const newField = { name: "new_field", type: "CharField", options: {} };
    const updatedModel = { ...model, fields: [...model.fields, newField] };
    updateModel(filteredIndex, updatedModel);
  };

  const updateField = (filteredIndex, fieldIndex, updatedField) => {
    const filtered = blueprint.data.models.filter((m) => m.app_name === currentApp);
    if (filteredIndex >= filtered.length) return;
    const model = filtered[filteredIndex];
    const fields = [...model.fields];
    fields[fieldIndex] = updatedField;
    const updatedModel = { ...model, fields };
    updateModel(filteredIndex, updatedModel);
  };

  const deleteField = (filteredIndex, fieldIndex) => {
    const filtered = blueprint.data.models.filter((m) => m.app_name === currentApp);
    if (filteredIndex >= filtered.length) return;
    const model = filtered[filteredIndex];
    const fields = model.fields.filter((_, i) => i !== fieldIndex);
    const updatedModel = { ...model, fields };
    updateModel(filteredIndex, updatedModel);
  };

  // ─── Other handlers ──────────────────────────────────────────────
  const handleStartProject = async () => {
    if (startAppName && !isValidAppName(startAppName)) {
      toast.error(
        "App name must be a valid Python identifier (letters, underscores, digits – no spaces or special chars)."
      );
      return;
    }
    setStartingProject(true);
    try {
      const result = await startProject(
        projectId,
        startFramework,
        startProjectName.trim() || undefined,
        startAppName.trim() || undefined
      );
      setBlueprint(result);
      toast.success("Project started!");
      setShowStartModal(false);
      setStartProjectName("");
      setStartAppName("");
      const appsData = await getAppsStructure(projectId);
      setApps(appsData);
      if (onProjectStarted) onProjectStarted();
      if (onRefreshWorkspace) onRefreshWorkspace();
    } catch (err) {
      toast.error(err.message || "Failed to start project");
    } finally {
      setStartingProject(false);
    }
  };

  const handleCreateApp = async () => {
    if (!newAppName.trim()) {
      toast.error("App name is required");
      return;
    }
    if (!isValidAppName(newAppName.trim())) {
      toast.error(
        "App name must be a valid Python identifier (letters, underscores, digits – no spaces or special chars)."
      );
      return;
    }
    setCreatingApp(true);
    try {
      await createApp(projectId, newAppName.trim());
      toast.success(`App '${newAppName.trim()}' created`);
      setShowNewAppModal(false);
      setNewAppName("");
      const appsData = await getAppsStructure(projectId);
      setApps(appsData);
      if (onRefreshWorkspace) onRefreshWorkspace();
    } catch (err) {
      toast.error(err.message || "Failed to create app");
    } finally {
      setCreatingApp(false);
    }
  };

  const handleDeleteApp = async (appName) => {
    if (!confirm(`Delete app "${appName}" and all its files? This cannot be undone.`)) return;
    try {
      await deleteApp(projectId, appName);
      toast.success(`App '${appName}' deleted`);
      const appsData = await getAppsStructure(projectId);
      setApps(appsData);
      if (currentApp === appName) {
        setCurrentApp(null);
        setView('apps');
      }
      if (onRefreshWorkspace) onRefreshWorkspace();
    } catch (err) {
      toast.error(err.message || "Failed to delete app");
    }
  };

  const handleCreateSuperuser = async () => {
    const { username, email, password, password2 } = superuserData;
    if (!username.trim()) {
      toast.error("Username is required.");
      return;
    }
    if (password.length < 8) {
      toast.error("Password must be at least 8 characters.");
      return;
    }
    if (password !== password2) {
      toast.error("Passwords do not match.");
      return;
    }
    setCreatingSuperuser(true);
    try {
      await createSuperuser(projectId, username.trim(), email.trim(), password, password2);
      toast.success(`Superuser '${username.trim()}' created!`);
      setShowSuperuserModal(false);
      setSuperuserData({ username: "", email: "", password: "", password2: "" });
    } catch (err) {
      toast.error(err.message || "Failed to create superuser");
    } finally {
      setCreatingSuperuser(false);
    }
  };

  const handleEnableAuth = async () => {
    if (
      !confirm(
        "🔐 Enable Authentication\n\n" +
        "This will generate a custom User model and JWT authentication endpoints.\n\n" +
        "⚠️ WARNING:\n" +
        "• Your current database (db.sqlite3) will be DELETED and recreated.\n" +
        "• ALL existing data will be LOST permanently.\n" +
        "• No backup will be created.\n\n" +
        "Only proceed if you are sure you want to reset your data.\n\n" +
        "Continue?"
      )
    ) return;
    setEnablingAuth(true);
    try {
      await enableAuth(projectId);
      toast.success("Authentication enabled successfully!");
      const appsData = await getAppsStructure(projectId);
      setApps(appsData);
      if (onRefreshWorkspace) onRefreshWorkspace();
    } catch (err) {
      toast.error(err.message || "Failed to enable authentication");
    } finally {
      setEnablingAuth(false);
    }
  };

  const handleItemClick = (appName, category, itemName) => {
    const fileMap = {
      models: "models.py",
      serializers: "serializers.py",
      views: "views.py",
      urls: "urls.py",
      admin: "admin.py",
      tests: "tests.py",
    };
    const filename = fileMap[category];
    if (filename && onSelectFile) {
      const filePath = `${appName}/${filename}`;
      onSelectFile(filePath);
    } else {
      toast(`Open ${itemName} in ${appName}/${filename || category}`, { icon: 'ℹ️' });
    }
  };

  // ─── Render ──────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="h-full flex items-center justify-center text-subtext">
        Loading builder...
      </div>
    );
  }

  if (!blueprint) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold glow-text mb-4">Visual Backend Builder</h2>
          <p className="text-subtext mb-6">
            Design your data models and generate a complete backend.
          </p>
          <button
            onClick={() => setShowStartModal(true)}
            className="px-6 py-3 bg-gradient-brand text-white rounded-md font-semibold hover:bg-gradient-brand-hover transition-all"
          >
            Start Project
          </button>
        </div>
        <StartProjectModal
          isOpen={showStartModal}
          onClose={() => setShowStartModal(false)}
          framework={startFramework}
          setFramework={setStartFramework}
          projectName={startProjectName}
          setProjectName={setStartProjectName}
          appName={startAppName}
          setAppName={setStartAppName}
          onSubmit={handleStartProject}
          loading={startingProject}
          isValidAppName={isValidAppName}
        />
      </div>
    );
  }

  // ─── Breadcrumb items ────────────────────────────────────────────
  const getBreadcrumbItems = () => {
    const items = ['Project'];
    if (view === 'apps' || view === 'app-details' || view === 'designer') {
      items.push('Backend');
    }
    if (view === 'app-details' || view === 'designer') {
      items.push(currentApp);
    }
    if (view === 'designer') {
      items.push(currentFeature);
    }
    return items;
  };

  // ─── Main render ──────────────────────────────────────────────────
  return (
    <div className="h-full flex flex-col bg-ink">
      {/* Header with close and action buttons */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-line shrink-0">
        <div className="flex items-center gap-3">
          <span className="text-sm text-subtext">
            {blueprint.framework} – {blueprint.data?.project_name || 'Unnamed'}
          </span>
          <button
            onClick={handleRefreshApps}
            className="text-xs px-2 py-0.5 bg-brand-100/20 text-brand-100 rounded hover:bg-brand-100/30 transition-colors"
          >
            ⟳
          </button>
        </div>
        <div className="flex gap-2">
          {view !== 'designer' && (
            <button
              onClick={handleGenerate}
              disabled={generating}
              className="text-xs px-3 py-1 bg-mint/20 text-mint rounded hover:bg-mint/30 transition-colors disabled:opacity-40"
            >
              {generating ? "Generating…" : "🚀 Generate"}
            </button>
          )}
          <button onClick={onClose} className="text-subtext hover:text-red-400 text-sm">
            ✕
          </button>
        </div>
      </div>

      {/* Breadcrumb */}
      {view !== 'home' && (
        <Breadcrumb
          items={getBreadcrumbItems()}
          onNavigate={navigateBreadcrumb}
        />
      )}

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        {view === 'home' && (
          <BuilderHome
            onSelectBackend={selectBackend}
            onSelectFrontend={selectFrontend}
          />
        )}

        {view === 'apps' && (
          <AppList
            apps={apps}
            onSelectApp={selectApp}
            onNewApp={() => setShowNewAppModal(true)}
          />
        )}

        {view === 'app-details' && (
          <AppDetails
            appName={currentApp}
            onSelectFeature={selectFeature}
            onBack={() => setView('apps')}
          />
        )}

        {view === 'designer' && currentFeature === 'models' && (
          <ModelDesigner
            appName={currentApp}
            models={designerModels}
            allModels={apps}
            onBack={() => setView('app-details')}
            onClose={onClose}
            onSave={saveBlueprint}
            saving={saving}
            onAddModel={addModel}
            onUpdateModel={updateModel}
            onDeleteModel={deleteModel}
            onAddField={addField}
            onUpdateField={updateField}
            onDeleteField={deleteField}
            onGenerate={handleGenerate}
            generating={generating}
            blueprintData={blueprint?.data}
            onUpdateBlueprintData={(newData) => {
              setBlueprint({
                ...blueprint,
                data: newData,
              });
            }}
          />
        )}
      </div>

      {/* Modals */}
      <NewAppModal
        isOpen={showNewAppModal}
        onClose={() => setShowNewAppModal(false)}
        appName={newAppName}
        setAppName={setNewAppName}
        onSubmit={handleCreateApp}
        loading={creatingApp}
        isValidAppName={isValidAppName}
      />

      <SuperuserModal
        isOpen={showSuperuserModal}
        onClose={() => setShowSuperuserModal(false)}
        data={superuserData}
        setData={setSuperuserData}
        onSubmit={handleCreateSuperuser}
        loading={creatingSuperuser}
      />

      {/* Enable Auth is triggered from AppList via button */}
      {/* We'll add an "Enable Auth" button in AppList header */}
    </div>
  );
}