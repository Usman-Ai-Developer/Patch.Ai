export default function Breadcrumb({ items, onNavigate }) {
  return (
    <div className="flex items-center gap-1 text-xs text-subtext/60 px-4 py-1.5 border-b border-line/30">
      {items.map((item, index) => (
        <span key={index} className="flex items-center gap-1">
          {index > 0 && <span className="text-subtext/40">/</span>}
          {index < items.length - 1 ? (
            <button
              onClick={() => onNavigate(index)}
              className="hover:text-brand-100 transition-colors cursor-pointer"
            >
              {item}
            </button>
          ) : (
            <span className="text-text">{item}</span>
          )}
        </span>
      ))}
    </div>
  );
}