"use client";

import { useState } from "react";

const CATEGORIES = [
  { key: "models", label: "Models", icon: "📄" },
  { key: "serializers", label: "Serializers", icon: "📄" },
  { key: "views", label: "Views", icon: "📄" },
  { key: "urls", label: "URLs", icon: "📄" },
  { key: "admin", label: "Admin", icon: "📄" },
  { key: "tests", label: "Tests", icon: "📄" },
];

export default function AppNode({
  app,
  expanded,
  toggleCategory,
  onItemClick,
  onAppClick,
  onDeleteApp,
}) {
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleFolder = () => {
    setIsExpanded(!isExpanded);
  };

  const handleAppClick = () => {
    if (onAppClick) onAppClick();
  };

  return (
    <div>
      {/* App folder row */}
      <div
        className="flex items-center justify-between py-1 px-2 hover:bg-panel/30 rounded cursor-pointer group"
        onClick={toggleFolder}
      >
        <div className="flex items-center gap-1" onClick={(e) => { e.stopPropagation(); handleAppClick(); }}>
          <span>{isExpanded ? "▾" : "▸"}</span>
          <span>📁</span>
          <span className="font-medium">{app.name}</span>
          <span className="text-xs text-subtext/60 ml-1">
            ({app.models?.length || 0} models)
          </span>
        </div>
        <button
          onClick={(e) => { e.stopPropagation(); onDeleteApp(); }}
          className="text-red-400 hover:text-red-300 opacity-0 group-hover:opacity-100 transition-opacity text-xs"
          title="Delete app"
        >
          ✕
        </button>
      </div>

      {/* Sub-items (models, serializers, etc.) */}
      {isExpanded && (
        <div className="ml-6 pl-3 border-l border-line/30 space-y-0.5">
          {CATEGORIES.map((cat) => {
            const items = app[cat.key] || [];
            if (items.length === 0) return null;
            const isCatExpanded = expanded[cat.key] || false;
            return (
              <div key={cat.key}>
                <div
                  className="flex items-center gap-1 py-0.5 px-2 hover:bg-panel/30 rounded cursor-pointer text-subtext text-sm"
                  onClick={() => toggleCategory(cat.key)}
                >
                  <span>{isCatExpanded ? "▾" : "▸"}</span>
                  <span>{cat.icon}</span>
                  <span>{cat.label}</span>
                  <span className="text-xs text-subtext/60 ml-1">({items.length})</span>
                </div>
                {isCatExpanded && (
                  <div className="ml-6 space-y-0.5">
                    {items.map((item) => (
                      <div
                        key={item}
                        className="flex items-center gap-1 py-0.5 px-2 hover:bg-panel/30 rounded cursor-pointer text-sm text-text"
                        onClick={() => onItemClick(cat.key, item)}
                      >
                        <span>📄</span>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}