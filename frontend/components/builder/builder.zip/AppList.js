export default function AppList({ apps, onSelectApp, onNewApp }) {
  // Predefined app icons and descriptions (could also be dynamic)
  const appMeta = {
    users: { icon: '👤', desc: 'Manage user accounts, authentication, profiles and permissions.' },
    jobs: { icon: '💼', desc: 'Manage job listings and positions.' },
    interviews: { icon: '📋', desc: 'Handle interviews and evaluations.' },
    hr: { icon: '🏢', desc: 'Human resource management.' },
    analytics: { icon: '📊', desc: 'Reports and analytics.' },
  };

  return (
    <div className="flex-1 overflow-y-auto p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-text">Installed Apps</h3>
        <button
          onClick={onNewApp}
          className="text-xs px-3 py-1 bg-brand-100/20 text-brand-100 rounded hover:bg-brand-100/30 transition-colors"
        >
          + Create New App
        </button>
      </div>

      {apps.length === 0 ? (
        <p className="text-subtext text-sm">No apps found. Create one using the button above.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {apps.map((app) => {
            const meta = appMeta[app.name.toLowerCase()] || { icon: '📦', desc: 'Manage your application.' };
            return (
              <div
                key={app.name}
                onClick={() => onSelectApp(app.name)}
                className="bg-panel border border-line rounded-lg p-4 hover:border-brand-100/50 transition-all cursor-pointer group"
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">{meta.icon}</span>
                  <div>
                    <h4 className="font-semibold text-text group-hover:text-brand-100 transition-colors">{app.name}</h4>
                    <p className="text-xs text-subtext mt-1">{meta.desc}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}