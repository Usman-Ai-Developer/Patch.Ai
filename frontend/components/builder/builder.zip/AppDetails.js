export default function AppDetails({ appName, onSelectFeature, onBack }) {
  const features = [
    { key: 'models', label: 'Models', icon: '📦', desc: 'Design database models and relationships' },
    { key: 'apis', label: 'APIs', icon: '🌐', desc: 'Configure API endpoints, viewsets and routes' },
    { key: 'permissions', label: 'Permissions', icon: '🔐', desc: 'Manage permissions, roles and access control' },
    { key: 'admin', label: 'Admin', icon: '⚙️', desc: 'Configure admin panel and interfaces' },
    { key: 'workflows', label: 'Workflows', icon: '🔄', desc: 'Automate processes and business logic' },
    { key: 'ai-actions', label: 'AI Actions', icon: '🤖', desc: 'AI powered actions and automations' },
    { key: 'settings', label: 'Settings', icon: '⚙️', desc: 'App configuration and custom settings' },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-4">
      <div className="flex items-center gap-2 mb-4">
        <button
          onClick={onBack}
          className="text-xs px-3 py-1 bg-brand-100/20 text-brand-100 rounded hover:bg-brand-100/30 transition-colors"
        >
          ← Back
        </button>
        <h3 className="text-sm font-semibold text-text">{appName}</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {features.map((feature) => {
          // Models is the only one implemented; others will show "Coming soon"
          const isImplemented = feature.key === 'models';
          return (
            <div
              key={feature.key}
              onClick={() => isImplemented && onSelectFeature(feature.key)}
              className={`bg-panel border border-line rounded-lg p-4 transition-all ${
                isImplemented
                  ? 'hover:border-brand-100/50 cursor-pointer group'
                  : 'opacity-60 cursor-not-allowed'
              }`}
            >
              <div className="flex items-start gap-3">
                <span className="text-2xl">{feature.icon}</span>
                <div>
                  <h4 className={`font-semibold ${isImplemented ? 'text-text group-hover:text-brand-100' : 'text-text/60'}`}>
                    {feature.label}
                  </h4>
                  <p className="text-xs text-subtext mt-1">{feature.desc}</p>
                  {!isImplemented && (
                    <span className="text-xs text-subtext/50 mt-1 block">Coming soon</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}